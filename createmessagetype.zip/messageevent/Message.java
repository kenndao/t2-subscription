/* File name: Message.java
 * 
 * Date: 05/19/17
 * 
 * Release: Alpha-verison 0.0.0 - prove of concept
 * 
 * Descriptions: 
 *  It contains a component class.  It has a receiveMessage method to process the message from the MessageHandler.  Got it from Spring document.
 *  is also known as a message driven POJO. As you can see in the code above, 
 *  there is no need to implement any particular interface or for the method to have any particular name. 
 *  Besides, the method may have a very flexible signature. Note in particular that this class has no import on the JMS API.
 *  The JmsListener annotation defines the name of the Destination that this method should listen to and the reference to the JmsListenerContainerFactory to use to create the underlying message listener container. Strictly speaking that last attribute is not necessary unless you need to customize the way the container is built as Spring Boot registers a default factory if necessary.
 * Properties: 
 * 
 *@Autowired
 *private MessageTypeRepository messageTypeRepository;
 * 
 * Methods:
 * receiveMessage(MessageHandler msg).

 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */  

package io.ken.subscriptionmain.messageevent;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

//import java.util.ArrayList;
//import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import io.ken.subscriptionmain.createmessagetype.MessageType;
import io.ken.subscriptionmain.createmessagetype.MessageTypeRepository;


@Component
public class Message {
	
	@Autowired
	private MessageTypeRepository messageTypeRepository;
	
	@JmsListener(destination = "mailbox", containerFactory = "myFactory")
	
	//Handle message from the messageHandler class
	public void receiveMessage(MessageHandler msg){
		try{	

			String id = msg.getMesssage();	
			List<MessageType> localMessages = new ArrayList<>();
			messageTypeRepository.findAll()
			.forEach(localMessages::add);
			
			for(int i=0; i< localMessages.size(); i++){
				MessageType local = localMessages.get(i);
				if(local.geteventType().equals(id)){
					int y = Integer.parseInt(local.getEventCount());
					y++;
					local.setEventCount(Integer.toString(y));		
					messageTypeRepository.save(local);
				}
			}
		}
		catch(Exception e){
			System.out.println("Exception error in receiveMessage()");
		}
		
	}
 
}
