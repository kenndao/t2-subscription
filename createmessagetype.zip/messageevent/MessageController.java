/* File name: MessageController.java
 * 
 * Date: 05/19/17
 * 
 * Release Verion: Alpha-verison 0.0.0.  Prove of concept.
 * 
 * Descriptions: It has a Web REST Controller.  It contains a post request from HTTP server:
 * This version it only includes: 
 * 
 * GET localhost:8080//postmessage/{message} => to publisher a message to the queue.
 * 
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */  


package io.ken.subscriptionmain.messageevent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//REST. Spring's annotation based MVC framework simplifies the process of creating RESTful web services.
@RestController
public class MessageController {
	
	//Dependency injection
	//Inject subscriptionService into this SubscriptionController class
	@Autowired
	private MessageService messageService;
	
	//Handle HTTP Post to create a subscription.
	@RequestMapping(method=RequestMethod.POST, value="/postmessage/{message}")
	public void postMessage(@PathVariable String message){	
		messageService.postMessage(message);
	}			
}
