/* File name: MessageHandler.java
 * 
 * Date: 05/19/17
 * 
 * Release: Alpha-verison 0.0.0 - prove of concept
 * 
 * Descriptions: It contains a POJO class.  It is a subscriber class to the email queue to receive messages from the publisher.
 * 
 * Properties: 
 * private String messsage;
 * 
 * Methods:
 * Getter and setter for message method
 *
 * 
 * Methods:
 * receiveMessage(MessageHandler msg).
 * 
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */  
package io.ken.subscriptionmain.messageevent;

public class MessageHandler {

    private String messsage;
   
  	public MessageHandler() {
    }

    public MessageHandler(String msg) {
        this.messsage = msg;
       }

    public String getMesssage() {
  		return messsage;
  	}

  	public void setMesssage(String messsage) {
  		this.messsage = messsage;
  	}
    @Override
    public String toString() {
        return String.format("Message{message=%s}", getMesssage());
    }

}