/* File name: MessageService.java
 * 
 * Date: 05/19/17
 * 
 * Release: Alpha-verison 0.0.0 - prove of concept
 * 
 * Descriptions: Using spring ActiveMQ to developed a publisher and consumer of JMS-based messages.
 * . 
 * 
 * Properties: 
 * @Autowired
	private DemoApplication demoApplication;
	
	Methods:
	public void postMessage(String message)
 *  
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */  

package io.ken.subscriptionmain.messageevent;

import javax.jms.ConnectionFactory;

import org.springframework.beans.factory.annotation.Autowired;

//import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.ConfigurableApplicationContext;
//import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.stereotype.Service;


import io.ken.DemoApplication;


@Service
@EnableJms

public class MessageService {
	
	@Autowired
	private DemoApplication demoApplication;	
	
	@Bean
	public JmsListenerContainerFactory<?> myFactory(ConnectionFactory connectionFactory,
            DefaultJmsListenerContainerFactoryConfigurer configurer) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		// This provides all boot's default to this factory, including the message converter
		configurer.configure(factory, connectionFactory);
		// You could still override some of Boot's default if necessary.
		return factory;
	}	
    @Bean // Serialize message content to json using TextMessage
    public MessageConverter jacksonJmsMessageConverter() {
        MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
        converter.setTargetType(MessageType.TEXT);
        converter.setTypeIdPropertyName("_type");
        return converter;
    }	
	public void postMessage(String message){	
		try{
			ConfigurableApplicationContext context = demoApplication.getContext();
			JmsTemplate jmsTemplate = context.getBean(JmsTemplate.class);
	        // Send a message with a POJO - the template reuse the message converter
	        jmsTemplate.convertAndSend("mailbox", new MessageHandler(message));	
		}
    	catch(Exception e){
			System.out.println("Exception error in postMessage()");
		}
	}

}
