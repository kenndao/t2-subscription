/* File name: SubscriptionService.java
 * 
 * Date: 05/19/17
 * 
 * Release: Alpha-verison 0.0.0 - prove of concept
 * 
 * Descriptions: This file has an Singleton class SubscriptionService (service). It provides methods to the SubscriptionController class
 * to access repository. 
 * 
 * Properties: 
 * @Autowired
	private SubscriptionRepository subscriptionRepository;
	
	Methods:
	getAllSubscriptions()
	getSubscription(String id)
 *  addSubscription(Subscription subBody)
 *  updateSubscription(Subscription subBody)
 *  
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */   

package io.ken.subscriptionmain.createsubscription;

import java.util.ArrayList;
//import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubscriptionService {
	@Autowired
	private SubscriptionRepository subscriptionRepository;
	
	//Return all created subscriptions
	public List<Subscription> getAllSubscriptions(){
		try{
			 List<Subscription> localMessages = new ArrayList<>();
			subscriptionRepository.findAll()
			.forEach(localMessages::add);
			return localMessages;
		}
		catch(Exception e){
			System.out.println("Exception error in getAllSubscriptions()");
			Subscription error = new Subscription();
			List<Subscription> localMessages = new ArrayList<>();
			localMessages.add(error);
			return localMessages;
		}
		
	}
	//Return a subscription which matches id.
	public Subscription getSubscription(String id){
		try{
			return subscriptionRepository.findOne(id);
		}
	   	catch(Exception e){
			System.out.println("Exception error in getSubscription()");
			Subscription error = new Subscription();
			return error;
		}
	}
	
	//Add a subscription to the database
	public void addSubscription(Subscription subBody){
		try{
			subscriptionRepository.save(subBody);
		}
	   	catch(Exception e){
			System.out.println("Exception error in addSubscription()");
		}
	}

	//Update an existing subscription
	public void updateSubscription(Subscription subBody) {
		try{
			subscriptionRepository.save(subBody);
		}
	   	catch(Exception e){
			System.out.println("Exception error in updateSubscription()");
		}
	}	
}
