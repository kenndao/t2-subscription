/* 
 * 
 * File name: SubscriptionRepopository.java
 * 
 * Date: 05/19/17
 * 
 * Release: Alpha-verison 0.0.0 - prove of concept
 * 
 * Descriptions: This file has an Java interface SubscriptionRepository that extends from JPA CrudRepository.  
 * The CrudRepository provides sophisticated CRUD functionality for the entity class that is being managed.
 * 
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */  

package io.ken.subscriptionmain.createsubscription;

import org.springframework.data.repository.CrudRepository;

public interface SubscriptionRepository extends CrudRepository<Subscription, String>{

}
