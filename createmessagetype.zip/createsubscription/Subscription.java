/* File name: Subscription.java
 * 
 * Date: 05/19/17
 * 
 * Release: Alpha-verison 0.0.0 - prove of concept
 * 
 * Descriptions: This file is the POJO class.  It contains subscription properties.  Using JPA to map it into table and has an Primary key Id.
 * 
 * Properties: 
 * 
 * @Id
 * private String id;
 * private String description;
 * 
 * Methods:
 * Get and set.
 *
 ** Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */  

package io.ken.subscriptionmain.createsubscription;
import javax.persistence.Entity;
import javax.persistence.Id;

// JPA annotation defines @Entity that a class can be mapped to a table
@Entity
public class Subscription {
	//Primary key annotation Id
	@Id
	private String id;
	private String description;
		
	//Default constructor
	public Subscription() {}

	//Constructor
	public Subscription(String id, String description) {
		super();
		this.id = id;
		this.description = description;
	}
	
	//properties get and set or helper functions********************************
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}


}
