/* File name: SubscriptionController.java
 * 
 * Date: 05/19/17
 * 
 * Release Verion: Alpha-verison 0.0.0.  Prove of concept.
 * 
 * Descriptions: This file is the Web REST Controller.  It should contain all the map web requests from HTTP methods:
 * This version it only includes: 
 * 
 * GET localhost:8080/subscriptions => to get all the created subscriptions by the user.
 * POST localhost:8080/subscriptions => to create new a subscription and insert it in the table. 
 * PUT localhost:8080/subscriptions/id => to update an exist subscription. 
 *
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */  


package io.ken.subscriptionmain.createsubscription;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//REST. Spring's annotation based MVC framework simplifies the process of creating RESTful web services.
@RestController
public class SubscriptionController {
	
	//Dependency injection
	//Inject subscriptionService into this SubscriptionController class
	@Autowired
	private SubscriptionService subscriptionService;
	
	//@RequestMapping annotation is used to map web requests onto specific handler classes and/or handler methods. 
	//Handle HTTP Get method for all created subscriptions
	@RequestMapping("/subscription")
	public List<Subscription> getAllSubscriptions(){	
		return subscriptionService.getAllSubscriptions();
	}
	//Handle HTTP Get an exist subscription 
	@RequestMapping("/subscription/{id}")
	public Subscription getSubscription(@PathVariable String id){	
		return subscriptionService.getSubscription(id);
	}		
	//Handle HTTP Post to create a subscription.
	@RequestMapping(method=RequestMethod.POST, value="/subscription")
	public void addSubscription(@RequestBody Subscription message){	
		subscriptionService.addSubscription(message);
	}		
	////Handle HTTP Put to update a subscription.
	@RequestMapping(method=RequestMethod.PUT, value="/subscription/{id}")
	public void updateSubscription(@RequestBody Subscription subBody, @PathVariable String id){	
		subscriptionService.updateSubscription(subBody);
	}	
	
}
