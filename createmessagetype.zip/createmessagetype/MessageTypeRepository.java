/* 
 * 
 * File name: MessageTypeRepopository.java
 * 
 * Date: 05/19/17
 * 
 * Release: Alpha-verison 0.0.0 - prove of concept
 * 
 * Descriptions: This file has an Java interface SubscriptionRepository that extends from JPA CrudRepository.  
 * The CrudRepository provides sophisticated CRUD functionality for the entity class that is being managed.
 * 
 * It includes a findBySubscriptionId(String id) methods to find all the messages belong to a subscription.
 * 
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */   
 
package io.ken.subscriptionmain.createmessagetype;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


public interface MessageTypeRepository extends CrudRepository<MessageType, String>{
	public List<MessageType> findBySubscriptionId(String id);	
	//public void saveBySubscriptionId(MessageType id);
}
