/* File name: MessageTypeService.java
 * 
 * Date: 05/19/17
 * 
 * Release: Alpha-verison 0.0.0 - prove of concept
 * 
 * Descriptions: This file has an Singleton class MessageTypeService (service). It provides methods to the MessageTypeController class
 * to access repository. 
 * 
 * Properties: 
 * @Autowired
	private MessageTypeRepository messageTypeRepository;
	
	Methods:
	getAllMessages()
	getMessage(String id)
 *  addMessage(Subscription subBody)
 *  updateMessage(Subscription subBody)
 *  
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */  
package io.ken.subscriptionmain.createmessagetype;

import java.util.ArrayList;
//import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MessageTypeService {
	@Autowired
	private MessageTypeRepository messageTypeRepository;
	
	public List<MessageType> getAllMessages(String subscriptionId){
		try{		
			List<MessageType> localMessages = new ArrayList<>();
			 messageTypeRepository.findBySubscriptionId(subscriptionId)
			.forEach(localMessages::add);
			return localMessages;
		}
		catch(Exception e){
			System.out.println("Exception error from getAllMessages()!");
			List<MessageType> localMessages = new ArrayList<>();
			return localMessages;
		}		
	}
	
	public MessageType getMessage(String id){
		try{
			return messageTypeRepository.findOne(id);
		}
		catch(Exception e){
			System.out.println("Exception error from getMessage()!");
			MessageType empty = new MessageType("error", "error","error","error");
			return empty;
		}
	}
	
	public void addMessage(MessageType message){
		try{
			//messageTypeRepository.save(message);
			messageTypeRepository.save(message);
		}
		catch(Exception e){
			System.out.println("Exception error from getMessage()!");
		}
	}

	public void updateMessage(MessageType message) {
		try{
			messageTypeRepository.save(message);
		}
		catch(Exception e){
			System.out.println("Exception error from getMessage()!");
		}				
	}

}
