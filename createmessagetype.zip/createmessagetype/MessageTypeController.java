/* File name: MessageTypeController.java
 * 
 * Date: 05/19/17
 * 
 * Release Verion: Alpha-verison 0.0.0.  Prove of concept.
 * 
 * Descriptions: This file is the Web REST Controller.  It contains the map web requests for HTTP methods:
 * This version it only includes: 
 * 
 * GET localhost:8080/subscriptions/{id}/messages => to get all the created messages belonging to a subscription id.
 * GET localhost:8080/subscriptions/{subcriptionId}/messages/{id} => get a message using the messageId from a subscription.
 * POST localhost:8080//subscriptions/{subscriptionId}/messages => to create new a message and insert it an subscription and table. 
 * 																=> get message from the http messsage body
 * PUT localhost:8080/subscriptions/{subcriptionId}/messages/{id}  => to update an exist message. 
 * 
 * Methods:  
 * List<MessageType> GetAllMessages(@PathVariable String id)
 * MessageType getMessage(@PathVariable String id)
 * void addMessage(@RequestBody MessageType message, @PathVariable String subscriptionId)
 * void updateMessage(@RequestBody MessageType message, @PathVariable String id, @PathVariable String subscriptionId)
 * 
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */  
 */
package io.ken.subscriptionmain.createmessagetype;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.ken.subscriptionmain.createsubscription.Subscription;

//REST controller annotation
@RestController
public class MessageTypeController {
	
	//dependency injection
	@Autowired
	private MessageTypeService messageSerivce;
	//private SubscriptionService subscriptionService;
	
	//Get REST request subscription
	//Return a list of subscription types have been subscribed
	@RequestMapping("/subscription/{id}/message")
	public List<MessageType> GetAllMessages(@PathVariable String id){
		return messageSerivce.getAllMessages(id);
	}
	//get a message 
	@RequestMapping("/subscription/{subcriptionId}/message/{id}")
	public MessageType getMessage(@PathVariable String id){	
		return messageSerivce.getMessage(id);
	}		
	//add a message
	@RequestMapping(method=RequestMethod.POST, value="/subscription/{subscriptionId}/message")
	public void addMessage(@RequestBody MessageType message, @PathVariable String subscriptionId){
		message.setSubscription(new Subscription(subscriptionId, ""));
		messageSerivce.addMessage(message);
		
	}		
	//update a message
	@RequestMapping(method=RequestMethod.PUT, value="/subscription/{subscriptionId}/message/{id}")
	public void updateMessage(@RequestBody MessageType message, @PathVariable String id, @PathVariable String subscriptionId){
		message.setSubscription(new Subscription(subscriptionId, ""));
		messageSerivce.updateMessage(message);
	}	
}
