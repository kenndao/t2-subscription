
/* File name: MessageType.java
 * 
 * Date: 05/19/17
 * 
 * Release: Alpha-verison 0.0.0 - prove of concept
 * 
 * Descriptions: This file is the POJO class.  It contains eventMessageType properties.  Using JPA to map it into table and has an Primary key Id.
 * 
 * Annotations and properties: 
 * @Entity
 * @Id
 * @ManyToOne
   private Subscription subscription;
   
   properties
 * private String id;
 * private String description;
 * private String eventCount;
 * 
 * Methods:
 * Get and set.
 * 
 * Copyright (C) Ken Nguyen - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ken Nguyen <kenndao@hotmail.com>, May 2017
 */ 
 

package io.ken.subscriptionmain.createmessagetype;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import io.ken.subscriptionmain.createsubscription.Subscription;

@Entity
public class MessageType {
	@Id
	private String id;
	private String eventType;
	private String eventCount;
	
	@ManyToOne
	private Subscription subscription;
	
	// Constructors
	public MessageType() {}
	public MessageType(String id, String description, String eventCount, String subscriptionId) {
		super();
		this.id = id;
		this.eventType = description;
		this.eventCount = eventCount;
		this.subscription = new Subscription(subscriptionId, "");
	}
	
	// property get set methods *******************
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String geteventType() {
		return eventType;
	}

	public void setDescription(String eventType) {
		this.eventType = eventType;
	}

	public String getEventCount() {
		return eventCount;
	}

	public void setEventCount(String eventCount) {
		this.eventCount = eventCount;
	}

	public Subscription getSubscription() {
		return subscription;
	}

	public void setSubscription(Subscription subscription) {
		this.subscription = subscription;
	}
}
